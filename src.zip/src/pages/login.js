'use client'

/* eslint-disable jsx-a11y/alt-text */
import React, { useState, useEffect } from 'react'
import Layout from '../components/layout_login'
import Container from 'react-bootstrap/Container'
import { Button, Form, Stack } from 'react-bootstrap'
import InputGroup from 'react-bootstrap/InputGroup'
import { HiUserCircle } from 'react-icons/hi'
import { RiLockPasswordFill } from 'react-icons/ri'
import { IconContext } from "react-icons"
import Link from 'next/link'
import { useForm } from "react-hook-form"
import { AiOutlineCheckCircle } from 'react-icons/ai'
import { MdOutlineCancel } from 'react-icons/md'
import Toast from 'react-bootstrap/Toast'
import ToastContainer from 'react-bootstrap/ToastContainer'
import Image from 'react-bootstrap/Image'
import Col from 'react-bootstrap/Col'
import Row from 'react-bootstrap/Row'
import { useRouter } from 'next/router'
import { useAuth } from '@/hooks/useAuth'
import { getProviders, getSession, signIn } from 'next-auth/react'
import { getCsrfToken } from "next-auth/react"



export default function Login({ csrfToken, providers }) {

    const [enviare, setEnviare] = useState(false)
    const { register, handleSubmit, watch, formState: { errors } } = useForm()
    const [show, setShow] = useState(false)
    const [messageNoti, setmessageNoti] = useState("")
    const router = useRouter()
    const auth = useAuth()

    useEffect(() => {
        if (router?.query?.error) {
            console.log(router?.query?.error)
          setShow(true)
          setmessageNoti(router?.query?.error)
        }
    }, [])

    const getUsuarioForm = async (data) => {
        console.log("haciendo submit")
        setShow(false)
        await signIn('credentials',{ email: data.email, password: data.password})
    }

    return (
        <>
            <Container className='divLogin'>
                <Row className='mt-md-4'>
                    <Col style={{textAling:'center'}}>
                        <Image alt="Logo" width="120" height="120" src="https://firebasestorage.googleapis.com/v0/b/changarrito-d9691.appspot.com/o/sources%2FChangarrito.png?alt=media&token=4b10a853-7cad-401a-94d4-b58618f9906a" />
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form  method="post" action="/api/auth/callback/credentials">
                            {errors.email?.type === 'required' && <span style={{ color: 'red' }}>El campo email es requerido</span>}
                            {errors.email?.type === 'pattern' && <span style={{ color: 'red' }}>El campo email es invalido</span>}
                            <InputGroup className="mb-5 mt-5" style={{ borderBottom: '5px solid rgba(255, 23, 68, 0.71)' }} >
                                <InputGroup.Text id="basic-addon1" >
                                    <IconContext.Provider value={{ size: '50px' }}>
                                        <HiUserCircle />
                                        {(!enviare == true) ? '' : (
                                            errors.email ?
                                                <IconContext.Provider value={{ size: '51px', color: 'red' }}>
                                                    <MdOutlineCancel />
                                                </IconContext.Provider>
                                                :
                                                <IconContext.Provider value={{ size: '51px', color: 'green' }}>
                                                    <AiOutlineCheckCircle />
                                                </IconContext.Provider>
                                        )
                                        }
                                    </IconContext.Provider>
                                </InputGroup.Text>
                                <Form.Control style={{ backgroundColor: 'rgba(217, 217, 217, 0.65)', borderradius: '10px 10px 0px 0px', height: '80px', color: '#000000', fontSize: '32px', fontWeight: '400', color: 'dark' }} className="text-center" placeholder="Email" {...register("email", {
                                    required: true,
                                    pattern: /^[a-z0-9_\-]+(\.[_a-z0-9\-]+)*@([_a-z0-9\-]+\.)+([a-z]{2}|aero|asia|arpa|biz|cat|com|coop|edu|gov|info|int|jobs|mil|mobi|museum|name|net|org|pro|tel|travel|xxx)$/,
                                })}></Form.Control>
                            </InputGroup>
                            {errors.password?.type === 'required' && <span style={{ color: 'red' }}>El campo password es requerido</span>}
                            {errors.password?.type === 'minLength' && <span style={{ color: 'red' }}>El campo password es minimo 8 caracteres</span>}
                            {errors.password?.type === 'maxLength' && <span style={{ color: 'red' }}>El campo password es maximo 30 caracteres</span>}

                            <InputGroup className="mb-5 mt-5" style={{ borderBottom: '5px solid rgba(255, 23, 68, 0.71)' }} >

                                <InputGroup.Text id="basic-addon1" >
                                    <IconContext.Provider value={{ size: '50px' }}>
                                        <RiLockPasswordFill />
                                        {(!enviare == true) ? '' : (
                                            errors.password ?
                                                <IconContext.Provider value={{ size: '51px', color: 'red' }}>
                                                    <MdOutlineCancel />
                                                </IconContext.Provider>
                                                :
                                                <IconContext.Provider value={{ size: '51px', color: 'green' }}>
                                                    <AiOutlineCheckCircle />
                                                </IconContext.Provider>
                                        )
                                        }
                                    </IconContext.Provider>
                                </InputGroup.Text>
                                <Form.Control style={{ backgroundColor: 'rgba(217, 217, 217, 0.65)', borderradius: '10px 10px 0px 0px', height: '80px', color: '#000000', fontSize: '32px', textTransform: 'capitalize', fontWeight: '400', color: 'dark' }} className="text-center" type="password" placeholder="Contraseña" {...register("password", {
                                    required: true,
                                    minLength: 8,
                                    maxLength: 30
                                })} />
                            </InputGroup>
                            <input name="csrfToken" type="hidden" defaultValue={csrfToken} />
                            <Stack direction='vertical' gap={1}>
                                <Button className="title mb-5" variant='primary' size="lg" type="submit" onClick={e => setEnviare(true)}>
                                    Entrar
                                </Button>
                            </Stack>
                        </Form>
                    </Col>
                </Row>
                <Row>
                    <Col style={{textAling:'center'}}>
                        <h4 className="title">Olvidaste tu contraseña?</h4>
                    </Col>
                </Row>
                <Row>
                    <Col style={{textAling:'center'}}>
                        <h4 className="title"><Link href="/register">Regístrate aquí</Link></h4>     
                    </Col>
                </Row>
                <Row>
                    <Col xs={6}>
                        <ToastContainer className="p-3" position="middle-center">
                            <Toast onClose={() => setShow(false)} show={show} delay={6000} autohide bg="Danger" >
                            <Toast.Header>
                                <Image
                                src="changarrito.png"
                                className="rounded me-2"
                                alt=""
                                width="20" height="20"
                                />
                                <strong className="me-auto"> Changarrito</strong>
                                <small>just now</small>
                            </Toast.Header>
                            <Toast.Body>{messageNoti}</Toast.Body>
                            </Toast>
                        </ToastContainer>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

// si logra ser autenticado, regresarlo a la página que intentó acceder
export async function getServerSideProps (context) {
    const providers = await getProviders()
    const csrfToken = await getCsrfToken(context)

    return {
        props: {
          providers,
          csrfToken
        },
    }
}

Login.getLayout = function getLayout(page) {
    return (
        <Layout>{page}</Layout>
    )
}
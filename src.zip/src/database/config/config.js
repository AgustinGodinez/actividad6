module.exports = {
  development_: {
    username: 'root',
    password: '',
    database: 'changarrito',
    host: 'localhost',
    dialect: 'mysql'
  },
  development: {
    username: 'admin',
    password: 'Transformacion2023#',
    database: 'changarrito',
    host: 'database-changarrito.ccgbjznbuuq7.us-east-1.rds.amazonaws.com',
    dialect: 'mysql'
  },
  test: {
    username: 'root',
    password: 'null',
    database: 'database_test',
    host: '127.0.0.1',
    dialect: 'mysql'
  },
  production: {
    username: 'root',
    password: 'null',
    database: 'database_production',
    host: '127.0.0.1',
    dialect: 'mysql'
  }
}

'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const process = require('process');
const basename = path.basename(__filename);
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.js')[env];
const db = {};

/* Custom handler for reading current working directory */
const models = process.cwd() + '/src/database/models/' || __dirname;

let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, {host:config.host, dialect: config.dialect });
}


fs
  .readdirSync(models)
  .filter(file => {
    return (
      file.indexOf('.') !== 0 &&
      file !== basename &&
      file.slice(-3) === '.js'
    );
  })
  .forEach(file => {
    const model = require(path.join(__dirname, file))(sequelize, Sequelize.DataTypes);
    db[model.name] = model;
  });


/*
db.Product = product(sequelize, Sequelize.DataTypes)
db.User = user(sequelize, Sequelize.DataTypes)
db.Category_product = Category_product(sequelize, Sequelize.DataTypes)
db.Category_seller = Category_seller(sequelize, Sequelize.DataTypes)
db.customer_address = customer_address(sequelize, Sequelize.DataTypes)
db.image_product = image_product(sequelize, Sequelize.DataTypes)
db.items_cart = items_cart(sequelize, Sequelize.DataTypes)
db.order_detail = order_detail(sequelize, Sequelize.DataTypes)
db.order_status = order_status(sequelize, Sequelize.DataTypes)
db.order = order(sequelize, Sequelize.DataTypes)
db.review_product = review_product(sequelize, Sequelize.DataTypes)
db.roles = roles(sequelize, Sequelize.DataTypes)
db.seller = seller(sequelize, Sequelize.DataTypes)
*/

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
